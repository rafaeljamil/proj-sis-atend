<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $bank = "db_app";
?>